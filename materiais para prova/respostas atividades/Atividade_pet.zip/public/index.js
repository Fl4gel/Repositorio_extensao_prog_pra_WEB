class Aluno {
  constructor(nome, nota_1, nota_2) {
    this.nome = nome;
    this.nota_1 = parseFloat(nota_1);
    this.nota_2 = parseFloat(nota_2);
  }

  calcMedia() {
    return (this.nota_1 + this.nota_2) / 2;
  }
}

let alunos = [];

function cadastrarAluno(event) {
  event.preventDefault();

  const nome = document.getElementById("nome").value;
  const nota_1 = document.getElementById("nota_1").value;
  const nota_2 = document.getElementById("nota_2").value;

  let aluno = new Aluno(nome, nota_1, nota_2);
  alunos.push(aluno);

  alunos.sort((a, b) => b.calcMedia() - a.calcMedia());

  let div = document.createElement("div");
  let texto = document.createTextNode(
    `Nome: ${nome} | Nota 1: ${nota_1} | Nota 2: ${nota_2} | Média: ${aluno
      .calcMedia()
      .toFixed(2)}`
  );
  div.appendChild(texto);
  document.getElementById('form_aluno').append(div);

  let maior_media = alunos[0];
  document.getElementById("maior_media").textContent = `A maior média foi de ${
    maior_media.nome
  } com Nota ${maior_media.calcMedia().toFixed(2)}`;

  let soma = alunos.reduce((total, aluno) => total + aluno.calcMedia(), 0);
  let media_turma = soma / alunos.length;
  document.getElementById(
    "media_turma"
  ).textContent = `A média da turma é de ${media_turma}`;
}
