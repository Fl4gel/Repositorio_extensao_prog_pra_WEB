document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById('formLivro');
    const listaLivros = document.querySelector('#listaLivros ul');
    const estatisticas = document.getElementById('estatisticas');
    const mostrarEstatisticasButton = document.getElementById('mostrarEstatisticas');

    let livros = [];

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const titulo = document.getElementById('titulo').value;
        const autor = document.getElementById('autor').value;
        const avaliacao = parseFloat(document.getElementById('avaliacao').value);

        if (isNaN(avaliacao) || avaliacao < 0 || avaliacao > 10) {
            alert('Avaliação inválida! Insira um valor entre 0 e 10.');
            return;
        }

        const novoLivro = {
            titulo,
            autor,
            avaliacao
        };

        livros.push(novoLivro);

        atualizarListaLivros();

        form.reset();
    });

    function atualizarListaLivros() {
        listaLivros.innerHTML = ''; 

        livros.forEach((livro, index) => {
            const li = document.createElement('li');

            li.textContent = `**${livro.titulo}** - ${livro.autor} (Avaliação: ${livro.avaliacao})`;

            listaLivros.appendChild(li);
        });
    }

    function atualizarEstatisticas() {
        if (livros.length === 0) {
            return; 
        }
    
        const mediaAvaliacao = calcularMediaAvaliacao(livros);
        const livroMelhorAvaliado = encontrarMelhorAvaliado(livros);
        const estatisticasParagrafos = estatisticas.querySelectorAll('p');
    
        if (estatisticasParagrafos.length < 2) {
            console.error("Erro: Elementos de estatísticas não encontrados ou incompletos.");
            return;
        }
    
        estatisticasParagrafos[0].textContent = `Média de Avaliação: ${mediaAvaliacao.toFixed(2)}`;
        estatisticasParagrafos[1].textContent = `Livro Melhor Avaliado: ${livroMelhorAvaliado.titulo} - ${livroMelhorAvaliado.autor} (Avaliação: ${livroMelhorAvaliado.avaliacao})`;
    }
    
    function calcularMediaAvaliacao(livros) {
        const totalAvaliacao = livros.reduce((soma, livro) => soma + livro.avaliacao, 0);
        return totalAvaliacao / livros.length;
    }

    function encontrarMelhorAvaliado(livros) {
        let melhorAvaliado = livros[0];

        for (let i = 1; i < livros.length; i++) {
            if (livros[i].avaliacao > melhorAvaliado.avaliacao) {
                melhorAvaliado = livros[i];
            }
        }

        return melhorAvaliado;
    }

    mostrarEstatisticasButton.addEventListener('click', () => {
        atualizarEstatisticas();
    });
});
